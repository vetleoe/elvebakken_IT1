function replace(){
    location.replace("index2.html")
}